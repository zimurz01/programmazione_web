from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import select, delete
from app.models.Event import Event
from app.models.registration import Registration
from app.data.db import SessionDep

router = APIRouter(prefix="/registrations")

@router.get("/")
#ottengo tutte le registrazioni
def get_all_registrations(session: SessionDep) -> list[Registration]:
    registrations=session.exec(select(Registration)).all()
    return registrations

@router.delete("/")
#cancello una registrazione
def delete_registration(
    username: str,
    event_id: int,
    session: SessionDep
):
    registration = session.exec(
        select(Registration).where(
            (Registration.event_id == event_id) & (Registration.username == username)
        )
    ).first() #ottengo registrazione con dato id e dato username
    if registration is None: #se reg non esiste, restistuisco 404
        raise HTTPException(status_code=404, detail="Registrazione non trovata")
    event = session.get(Event, event_id) #ottengo l'evento a partire dall'id per restituire il titolo dell'evento
    session.delete(registration) #cancello registrazione
    session.commit()
    return {"message": f"La prenotazione dell'utente {username} è stata cancellata dall'evento {event.title}"}