from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import select, delete
from app.models.Event import Event, CreaEventi
from app.models.registration import Registration, CreaRegistrazione
from app.models.User import User, CreaUtente
from app.data.db import SessionDep

router= APIRouter(prefix="/events")

@router.get("/")
#api per ottenere la lista di tutti gli eventi
def get_all_events(session: SessionDep) -> list[Event]:
    eventi = session.exec(select(Event)).all()
    return eventi

@router.post("/")
#api per aggiungere un nuovo evento
def add_event(session: SessionDep, new_event: CreaEventi):
    nuovo_evento=Event(**new_event.dict())
    session.add(nuovo_evento) #aggiungo nuovo evento al database
    session.commit()
    return {"messaggio": f"{nuovo_evento.title} è stato registrato con successo!"}

@router.delete("/")
#api per cancellare tutti gli eventi
def delete_all_events(session: SessionDep):
    session.exec(delete(Registration))#elimino tutte le registrazioni agli eventi
    session.exec(delete(Event))#elimino tutti gli eventi
    session.commit()
    return {"Messaggio":"Tutti gli eventi son stati eliminati"}

@router.delete("/{id}")
#elimino un singolo evento
def delete_single_event(session: SessionDep, id:int):
    event = session.get(Event, id)
    if event is None: #controllo se l'evento esiste, se non esiste error 404
        raise HTTPException(status_code=404, detail="L'evento non esiste")
    session.delete(event)#cancello l'evento
    session.commit()
    return {"messaggio": "Evento cancellato con successo"}

@router.get("/{id}")
#ottengo un evento con un id specifico
def get_event_id(session: SessionDep, id: int):
    event=session.get(Event, id)
    if event is None: #controllo se l'evento esiste, se non esiste error 404
        raise HTTPException(status_code=404, detail="L'evento non esiste")
    return event

@router.put("/{id}")
#aggiorno evento, mantengo l'id uguale ed aggiorno tutti i suoi altri parametri in caso siano da cambiare
def aggiorna_evento(session:SessionDep, id:int, nuovo_evento: CreaEventi):
    event=session.get(Event, id)
    if event is None: #controllo se l'evento esiste, se non esiste error 404
        raise HTTPException(status_code=404, detail="L'evento non esiste")
    event.title= nuovo_evento.title #aggiorno i vari parametri, passando in ingresso i nuovi. id non cambia
    event.description = nuovo_evento.description
    event.date = nuovo_evento.date
    event.location = nuovo_evento.location
    session.commit()
    return {"messaggio": f"Evento {id} modificato con successo"}

@router.post("/{id}/register")
#registro un utente ad un evento
def registra_utente_ad_evnto(session:SessionDep, id:int, registrazione: CreaRegistrazione):
    event=session.get(Event, id)
    if event is None: #controllo evento
        raise HTTPException(status_code=404, detail="L'evento non esiste")
    user=session.get(User, registrazione.username)
    if user is None: #controllo utente
        raise HTTPException(status_code=404, detail="L'utente non esiste")
    check=session.exec(select(Registration).where((Registration.event_id==id)
                       & (Registration.username==registrazione.username))).first() #controllo se utente già iscritto ad evento con id dato
    if check is None: #se utente non iscritto, iscrivo utente ad evento
        nuova_reg= Registration(username=registrazione.username, event_id=id)
        session.add(nuova_reg)
        session.commit()
        return {"messaggio": f"{user.username} registrato con successo ad {event.title} in data {event.date}"}
    else:
        raise HTTPException(status_code=400, detail="Utente già registrato") #errore 400 in caso utente sia già registrato

