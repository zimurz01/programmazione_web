from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import select, delete
from app.models.User import User, CreaUtente
from app.models.registration import Registration
from app.data.db import SessionDep

router= APIRouter(prefix="/users")

@router.get("/")
#restituisce una lista con tutti gli utenti
def get_all_users(session: SessionDep) -> list[User]:
    users = session.exec(select(User)).all()
    return users


@router.post("/")
#aggiunge un utente
def add_user(session: SessionDep, user: CreaUtente):
    controllo_username = session.get(User, user.username)
    if controllo_username:  #controllo se username già utilizzato, se già utilizzato errore 400
        raise HTTPException(status_code=400, detail="Nome utente già esistente")
    nuovo_utente=User(**user.dict())
    session.add(nuovo_utente) #aggiungo utente al database
    session.commit()
    return {"messagggio": f"Utente aggiunto con successo! Benvenuto {nuovo_utente.username}!"}

@router.delete("/")
#cancello tutti gli utenti
def delete_all_users(session: SessionDep):
    session.exec(delete(Registration))
    session.exec(delete(User))
    session.commit()
    return {"messaggio": "Tutti gli utenti sono stati cancellati con successo"}


@router.delete("/{username}")
#cancello utente specifico username
def delete_single_user(username: str, session: SessionDep):
    utente = session.exec(select(User).where(User.username == username)).first()
    if not utente: #controllo se utente esiste, se non esiste errore 404
        raise HTTPException(status_code=404, detail="Utente non trovato")
    registrazioni = session.exec(
        select(Registration).where(Registration.username == username)
    ).all() #seleziono e poi cancello tutte le registrazioni a cui l'utente è iscritto
    for r in registrazioni:
        session.delete(r)
    session.delete(utente) #cancello l'utente
    session.commit()
    return {"messaggio": f"Utente '{username}' e relative registrazioni eliminati con successo"}

@router.get("/{username}")
#ottengo utente a partire dall'username
def get_user_by_username(username: str, session: SessionDep) -> User:
    utente = session.exec(select(User).where(User.username == username)).first()
    if not utente: #controllo se l'utente esiste, se non estste error 404
        raise HTTPException(status_code=404, detail="Utente non trovato")
    return utente
