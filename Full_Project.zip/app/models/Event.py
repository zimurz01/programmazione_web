from sqlmodel import SQLModel, Field
from datetime import datetime

class Event(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True) #parametri per evento, primary key per identificarlo
    title: str
    description : str = Field(max_length=200)
    date : datetime
    location : str


class CreaEventi(SQLModel):
    title: str
    description: str
    date: datetime
    location: str