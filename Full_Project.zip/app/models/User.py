from sqlmodel import SQLModel, Field


class User(SQLModel, table=True):
    username: str = Field(primary_key=True, min_length=1, max_length=150) #parametri per utente, primary key per identificarlo
    name : str
    email : str

class CreaUtente(SQLModel):
    username: str
    name: str
    email: str